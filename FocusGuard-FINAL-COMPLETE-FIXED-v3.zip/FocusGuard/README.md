# FocusGuard

FocusGuard is a personal Android accessibility utility that reduces Instagram feed distractions.

## Current behavior

- Covers the Instagram Home feed/post area while leaving the header and Stories area visible.
- The covered Home area consumes touches, so posts cannot be opened, liked, or scrolled through.
- Covers the Reels tab button and returns to Home if the Reels tab is reached by a gesture.
- Covers the idle Explore grid while leaving the Search field usable.
- Direct/DM screens remain usable.
- A Reel opened from a Direct/DM message is allowed to play.
- A vertical scroll while viewing a shared Reel returns to the Direct/DM screen instead of advancing to another Reel.
- Uses an Instagram-like light background (#FFFFFF) and dark background (#0C0F14); dark mode or Battery Saver selects the dark palette.

## Build

GitHub Actions builds a debug APK from `app/build/outputs/apk/debug/app-debug.apk` and uploads it as `FocusGuard-debug-apk`.

## Important

Instagram's internal accessibility IDs can change between app releases. This project therefore checks several known IDs and also uses screen geometry as a fallback for the Home feed. Test after Instagram updates.

The Accessibility Service can inspect the active app's UI and draw a touchable overlay. Enable it only if you understand and trust the service.
