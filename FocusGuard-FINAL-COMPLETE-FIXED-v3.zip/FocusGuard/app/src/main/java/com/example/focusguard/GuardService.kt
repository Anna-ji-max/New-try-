package com.example.focusguard

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

private const val IG = "com.instagram.android"

// Instagram changes these IDs between releases, so several known variants are checked.
private val REEL_PLAYER_IDS = listOf(
    "reel_recycler", "reel_player_page_container", "clips_view_pager", "reel_viewer_root"
)
private val TAB_BAR_IDS = listOf("tab_bar", "bottom_tab_bar")
private val HOME_TAB_IDS = listOf("feed_tab", "home_tab")
private val SEARCH_TAB_IDS = listOf("search_tab", "search_tab_button")
private val REELS_TAB_IDS = listOf("clips_tab", "reels_tab")
private val DIRECT_TAB_IDS = listOf(
    "direct_tab", "direct_tab_button", "action_bar_inbox", "inbox_tab", "messenger_tab"
)
private val SEARCH_BOX_IDS = listOf("action_bar_search_edit_text", "search_edit_text")

private val DARK_BG = 0xFF0C0F14.toInt()
private val LIGHT_BG = 0xFFFFFFFF.toInt()

data class Colors(val bg: Int, val text: Int, val sub: Int, val accent: Int)

private object Palette {
    private val LIGHT = Colors(LIGHT_BG, 0xFF262626.toInt(), 0xFF737373.toInt(), 0xFF0095F6.toInt())
    private val DARK = Colors(DARK_BG, 0xFFFAFAFA.toInt(), 0xFFA8A8A8.toInt(), 0xFF0095F6.toInt())

    fun now(c: Context): Colors {
        val night = (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        val saver = (c.getSystemService(Context.POWER_SERVICE) as PowerManager).isPowerSaveMode
        return if (night || saver) DARK else LIGHT
    }
}

object Quotes {
    val full = listOf(
        "You came here for a reason. Go do that.",
        "Your time is the one thing you can't scroll back.",
        "Be where your feet are.",
        "Close the feed. Open your day.",
        "Nothing here is as good as what you're about to do."
    )
    val tile = listOf("Focus", "Be here", "Not now", "Breathe")
}

class GuardService : AccessibilityService() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private val views = HashMap<String, View>()
    private val rects = HashMap<String, Rect>()
    private var pending = false

    // True when the user entered a reel viewer from a Direct/DM screen.
    // Shared reels are allowed to play, but scrolling to another reel is immediately
    // cancelled by returning to the Direct screen.
    private var directContext = false
    private var reelWasOpenedFromDirect = false
    private var backingFromSharedReel = false

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.packageName == packageName) return

        val root = rootInActiveWindow
        if (root?.packageName == IG) {
            // Catch a vertical reel-page scroll after Instagram has accepted it.
            // This lets a shared reel play normally, but prevents advancing to another reel.
            if (reelWasOpenedFromDirect &&
                e.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED &&
                !backingFromSharedReel
            ) {
                val sourceId = e.source?.viewIdResourceName.orEmpty()
                if (sourceId.contains("reel", ignoreCase = true) ||
                    sourceId.contains("clip", ignoreCase = true) ||
                    REEL_PLAYER_IDS.any { sourceId.endsWith(":id/$it") }
                ) {
                    backingFromSharedReel = true
                    ui.postDelayed({
                        performGlobalAction(GLOBAL_ACTION_BACK)
                        ui.postDelayed({ backingFromSharedReel = false; evaluate() }, 250)
                    }, 30)
                    return
                }
            }
        }

        if (pending) return
        pending = true
        ui.postDelayed({ pending = false; evaluate() }, 60)
    }

    override fun onInterrupt() = hideAll()
    override fun onDestroy() { hideAll(); super.onDestroy() }

    private fun evaluate() {
        val root = rootInActiveWindow
        if (root == null || root.packageName != IG) {
            hideAll()
            return
        }

        val screen = bounds(root)
        val bar = first(root, TAB_BAR_IDS)
        val homeSelected = isSelected(root, HOME_TAB_IDS)
        val directNow = isDirectScreen(root)
        val reelOpen = REEL_PLAYER_IDS.any { find(root, it) != null }

        if (!reelOpen && directNow) reelWasOpenedFromDirect = false
        if (!reelOpen && directNow) directContext = true
        if (!reelOpen && !directNow && homeSelected) directContext = false
        if (!reelOpen && isSelected(root, SEARCH_TAB_IDS)) directContext = false

        // Reels opened from a Direct message are allowed to play. A vertical swipe is
        // handled above and returns to the Direct screen instead of moving to another reel.
        if (reelOpen) {
            hide("feed")
            hide("region")
            hide("tile")
            if (reelWasOpenedFromDirect || directContext) {
                reelWasOpenedFromDirect = true
                hide("full")
            } else {
                show("full", screen, Quotes.full.random(), 22f, back = true)
            }
            return
        }

        hide("full")

        // If the user reached the Reels tab by tapping it OR by a gesture, immediately
        // return to Home. The tab itself is also covered so the normal tap is unavailable.
        val reelsTab = first(root, REELS_TAB_IDS)
        val reelsSelected = reelsTab?.isSelected == true
        if (reelsSelected) {
            goHome()
            return
        }

        // HOME: cover the entire post/feed area, not just the media of one post.
        // The top ~24% is left untouched for Instagram's header + Stories. The exact
        // story height varies by device, so a small node-based adjustment is attempted first.
        if (bar != null && homeSelected) {
            val feedTop = findStoryBottom(root, screen) ?: (screen.top + (screen.height() * 0.235f).toInt())
            val feedBottom = bounds(bar).top
            if (feedBottom > feedTop + dp(20)) {
                showBlank("feed", Rect(screen.left, feedTop, screen.right, feedBottom))
            } else {
                hide("feed")
            }
        } else {
            hide("feed")
        }

        // SEARCH/EXPLORE: keep the search field usable but cover the idle Explore grid.
        val box = first(root, SEARCH_BOX_IDS)
        val idle = box == null || ((box.isShowingHintText || box.text.isNullOrEmpty()) && !box.isFocused)
        if (bar != null && isSelected(root, SEARCH_TAB_IDS) && idle) {
            val top = if (box != null) bounds(box).bottom else screen.top + dp(112)
            show("region", Rect(screen.left, top, screen.right, bounds(bar).top), Quotes.full.random(), 18f)
        } else {
            hide("region")
        }

        // Cover the Reels button itself while leaving Home/Search/DM/Profile available.
        if (reelsTab != null && !reelsSelected) {
            show("tile", bounds(reelsTab), Quotes.tile.random(), 9f)
        } else {
            hide("tile")
        }
    }

    private fun isDirectScreen(root: AccessibilityNodeInfo): Boolean {
        if (DIRECT_TAB_IDS.any { find(root, it) != null }) return true
        return containsText(root, listOf("Direct", "Messages", "Messenger", "Inbox"))
    }

    private fun findStoryBottom(root: AccessibilityNodeInfo, screen: Rect): Int? {
        val names = listOf(
            "reel_tray_container", "stories_tray", "story_tray", "row_feed_story",
            "reel_viewer_container", "reel_viewer_root"
        )
        val candidate = names.asSequence()
            .mapNotNull { find(root, it) }
            .map { bounds(it) }
            .filter { it.width() > screen.width() * 0.6 && it.top < screen.height() * 0.45 }
            .maxByOrNull { it.bottom }
        return candidate?.bottom
    }

    private fun containsText(node: AccessibilityNodeInfo?, values: List<String>): Boolean {
        if (node == null || !node.isVisibleToUser) return false
        val hay = listOfNotNull(node.text?.toString(), node.contentDescription?.toString())
            .joinToString(" ")
        if (values.any { hay.contains(it, ignoreCase = true) }) return true
        for (i in 0 until node.childCount) {
            if (containsText(node.getChild(i), values)) return true
        }
        return false
    }

    private fun isSelected(root: AccessibilityNodeInfo, ids: List<String>): Boolean =
        ids.asSequence().mapNotNull { find(root, it) }.any { it.isSelected }

    private fun first(root: AccessibilityNodeInfo, ids: List<String>): AccessibilityNodeInfo? =
        ids.asSequence().mapNotNull { find(root, it) }.firstOrNull()

    private fun find(root: AccessibilityNodeInfo, name: String): AccessibilityNodeInfo? =
        root.findAccessibilityNodeInfosByViewId("$IG:id/$name").firstOrNull { it.isVisibleToUser }

    private fun bounds(n: AccessibilityNodeInfo) = Rect().also { n.getBoundsInScreen(it) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun show(key: String, r: Rect, msg: String, sp: Float, back: Boolean = false) {
        val existing = views[key]
        try {
            if (existing != null) {
                if (rects[key] != r) wm.updateViewLayout(existing, params(r))
            } else {
                val v = build(msg, sp, back)
                wm.addView(v, params(r))
                views[key] = v
            }
            rects[key] = r
        } catch (_: Exception) { }
    }

    private fun showBlank(key: String, r: Rect) {
        val existing = views[key]
        try {
            if (existing != null) {
                if (rects[key] != r) wm.updateViewLayout(existing, params(r))
            } else {
                val v = buildBlank()
                wm.addView(v, params(r))
                views[key] = v
            }
            rects[key] = r
        } catch (_: Exception) { }
    }

    private fun buildBlank(): View {
        val c = Palette.now(this)
        return View(this).apply {
            setBackgroundColor(c.bg)
            isClickable = true
            isFocusable = false
            setOnTouchListener { _, _ -> true }
        }
    }

    private fun hide(key: String) {
        rects.remove(key)
        views.remove(key)?.let { try { wm.removeView(it) } catch (_: Exception) { } }
    }

    private fun hideAll() = views.keys.toList().forEach { hide(it) }

    // Deliberately touchable: the covered area consumes taps and swipes so Instagram cannot
    // open a post, like it, or scroll to another post/reel underneath the blocker.
    private fun params(r: Rect) = WindowManager.LayoutParams(
        r.width(), r.height(),
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.OPAQUE
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = r.left
        y = r.top
    }

    private fun build(msg: String, sp: Float, back: Boolean): View {
        val c = Palette.now(this)
        val pad = dp(if (sp > 12f) 32 else 2)
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(c.bg)
            setPadding(pad, 0, pad, 0)
            isClickable = true
            setOnTouchListener { _, _ -> true }
            addView(TextView(context).apply {
                text = msg
                textSize = sp
                gravity = Gravity.CENTER
                setTextColor(c.text)
            })
            if (back) addView(Button(context).apply {
                text = "Back to Home"
                isAllCaps = false
                setTextColor(0xFFFFFFFF.toInt())
                background = GradientDrawable().apply {
                    setColor(c.accent)
                    cornerRadius = dp(8).toFloat()
                }
                setOnClickListener { goHome() }
            }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(24) })
        }
    }

    private fun goHome() {
        val root = rootInActiveWindow
        val home = root?.let { first(it, HOME_TAB_IDS) }
        if (home?.performAction(AccessibilityNodeInfo.ACTION_CLICK) != true) {
            performGlobalAction(GLOBAL_ACTION_BACK)
        }
    }
}
